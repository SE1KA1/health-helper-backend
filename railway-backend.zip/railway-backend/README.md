Railway deployment package for Health Helper AI backend.

Replace agent.py with your real agent implementation and add model files into model/ before deploying.
